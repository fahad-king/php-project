<html>
<head>
  <link rel="stylesheet" href="../plugins/css/bootstrap.min.css">
  <script src="../plugins/js/jquery-2.2.2.js"></script>
  <script src="../plugins/js/bootstrap.min.js"></script>
  <script src="../plugins/js/jquery.cycle.all.js"></script>
   <link href="../plugins/css/mycss.css" rel="stylesheet">
   <link href="../plugins/css/font.css" rel="stylesheet">
   <link href="../plugins/css/mycss2.css" rel="stylesheet">
   <link href="../plugins/css/style.css" rel="stylesheet">


    <script type="text/javascript">
        $('#slider').cycle({
            fx:     'fade',
            fx:     'scrollVert',
            speed:  'slow',
            tomeout: .2
        });</script>
</head>
<body>
<div class="container">    
  <div id="slider">
	     <!-- <img src="ragam.gif">-->
          
          <img src="slider-img/nita.png"/>
          <img src="slider-img/nitclt.png"/>
	     
       </div> 
<br>
</div>
</body>
</html>