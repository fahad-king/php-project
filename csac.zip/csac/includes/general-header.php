<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Case</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../plugins/css/bootstrap.min.css">
	<link rel="stylesheet" href="../plugins/css/mycss.css">
	<link rel="stylesheet" href="../plugins/css/mycss2.css">
	<link rel="stylesheet" href="../plugins/css/mystyle.css">
	<link rel="stylesheet" href="../plugins/css2/mystyle.css">
    <script src="../plugins/js/bootstrap.min.js"></script>
    <script src="../plugins/js/jquery-2.2.2.js"></script>
	<script src="../plugins/js/jquery.cycle.all.js"></script>
	
	<script type="text/javascript">
/* 
	If You Want Slider Then Enable It ...@amit	
$('#slider').cycle({ 
    fx:     'fade',
	fx:     'scrollHorz', 
    speed:  'slow',
	tomeout: 5,  
    next:   '#next', 
    prev:   '#prev' 
});*/
$('#slider').cycle({ 
    fx:      'custom', 
    cssBefore: {  
    			  left: 200,  
    			  top:  200,  
    			  width: 0,  
   			 	  height: 0,  
    			  opacity: 1, 
    			  display: 'block' 
    			}, 
    animOut: 	{  
    			  opacity: 0  
    		    }, 
    animIn:     {  
    			  left: 0,  
    			  top: 0,  
    			  width: 1067,  
    			  height: 500  
    		    }, 
    cssAfter:   {  
    			 zIndex: 0 
    			}, 
    delay: 4000 
});
</script>

</head>
<body>
    <div class="wellcome well-sm ">
        <form action="../login.php" method="post">
            <table id="login-table">
                <tr>
                    <td><b>User Name :</b></td>
                    <td>&nbsp;&nbsp;<input type="text" name="username" required="required"></td>
                    <td>&nbsp;&nbsp;<b>PassWord:</b></td>
                    <td>&nbsp;&nbsp;<input type="password" name="pass" required="required"></td>
                    <td></td>
                    <td>&nbsp;&nbsp;<input type="submit" name="save" value="Login" class=".btn-success"></td>
                </tr>
            </table>
        </form>
    <!--  Form End here .........-->
    </div>
	<div class="well">
        <div id="slider">
	     <!-- <img src="ragam.gif">-->
          <img src="slider-img/nit_1.jpg"/>
          <img src="slider-img/nit_2.jpg"/>
          <img src="slider-img/nit_3.jpg"/>
	      <img src="slider-img/nit_4.jpg"/>
	      <img src="slider-img/nit_5.jpg"/>
	      <img src="slider-img/nit_6.jpg"/>
	  	  <img src="slider-img/nit_7.jpg"/>
	  	  <img src="slider-img/nit_8.jpg"/>
	  	  <img src="slider-img/nit_9.jpg"/>
	  	  <img src="slider-img/nit_10.jpg"/>  
         </div> 
	   </div>
	   
	   <div class="menu col-xs-12 menu col-sm-2 col-md-4 col-lg-12">
  <ul>
	<li><a href="home.php">Home</a></li>
	<li><a>Registration</a>
		<ul>
		  <li><a href="new_reg.php">New</a></li>
		  <li><a href="#">LogIn</a>
		  	<ul>
		   		<li><a href="#">l1</a></li>
		  		<li><a href="#">l2</a></li>
		  		<li><a href="#">l3?</a></li>
			</ul> 
		  </li>
		  <li><a href="#">Password?</a></li>
		</ul> 
	</li>
	<li><a>Downloads</a>
		<ul>
			<li><a href="#">Previous Papers</a>
				<ul>
					<li><a href="#">2015</a></li>
					<li><a href="#">2014</a></li>
					<li><a href="#">2013</a></li>
					<li><a href="#">2012</a></li>
					<li><a href="#">2011</a></li>
				</ul>
			</li>
			<li><a href="#">Information Broucher</a></li>
			<li><a href="#">Instruction</a></li>
			<li><a href="#">Admit Card</a></li>
			
		</ul>
	</li>
	<li><a><b>I</b>mp Dates</a>
	    <ul>
			<li><a href="#">Closing Date</a></li>
			<li><a href="#">Exam Date</a></li>
			
			
		</ul>
	</li>
	<li><a>Seat Matrix</a>
		<ul>
			<li><a href="#">OBC</a></li>
			<li><a href="#">ST</a></li>
			<li><a href="#">SC</a></li>
			<li><a href="#">Other Nation</a></li>
		</ul>
	</li>
	<li><a >Support</a>
	   <ul>
		 <li><a href="#">Controller</a>
		    <ul>
		     <li><a href="#">Live Chat</a></li>
			 </ul>
		 </li>	  
		 <li><a href="#">Help Desk</a></li>
		 <li><a href="#">Other</a></li>
	   </ul>
	</li>
	<li><a href="spot_err.php">Payment Procedure</a></li>
	<li><a href="faq.php">FAQ</a></li>
	</ul>
  </div> <!-- Menu Ends Here-->  
<!-- Menu Header and slider  starts Here-->

<div class="container">
    <p>Hello thiss sIs Th eContaoner </p>
</div>


<script src="../plugins/js/bootstrap.min.js"></script>
<script src="../plugins/js/jquery-2.2.2.js"></script>
</body>
</html>