<?php
require ('connect.php');
//require ('login.php');
session_start();
if(isset($_SESSION['username']))
  {
      echo 'welcome page Testing ';
  }
else {
    header('location:index.php');
}
?>
<html>
<head>
    <titile>Welcome <?php echo $_SESSION['username'];?></titile>
</head>

<body>
        <a href="logout.php">LOgOut Me Out</a>

</body>
</html>

