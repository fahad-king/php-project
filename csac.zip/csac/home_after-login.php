<?php
require ('4-4-16/connect.php');
//require ('login.php');
session_start();
if(!isset($_SESSION['username']))
  {
      header('Location:4-4-16/welcome.php');
	  exit();
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="plugins/css/mycss.css" rel="stylesheet" />
    <link href="plugins/css/bootstrap.css" rel="stylesheet" />
    <link href="plugins/css/bootstrap-theme.min.css" rel="stylesheet" />
    <link href="plugins/css/mycss2.css"  rel="stylesheet" />
    <link href="plugins/css/font.css" rel="stylesheet" />
    <link href="plugins/css/container.css" rel="stylesheet" />
    <link href="plugins/css/style.css" rel="stylesheet">
    <link href="footer-header/form-footer-header.css" rel="stylesheet">
    <script type="text/javascript" src="plugins/js/alert.js"></script>
    <script type="text/javascript" src="plugins/js/jquery-2.2.2.js"></script>
    <script type="text/javascript" src="plugins/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="plugins/js/jquery.cycle.all.js"></script>

    <script type="text/javascript">
        $('#slider').cycle({
            //fx:     'fade',
            fx:     'scrollHorz',
            speed:  'slow',
            tomeout:.1000
        });
    </script>
    <style>
    .container {
        border-radius: 2px;
       //background-color: #5bc0de;
    }
     #slider{
         margin-left: 30px;
         margin-right: 30px;
         margin-top: 10px;
         margin-bottom: 2px;
         -webkit-border-radius: 30px;
         -moz-border-radius: 30px;
         border-radius: 30px !important;
     }
    .left-side p{
            text-align: center;
     }
    .collapse {
        background-color: #23527c; !important;
    }
    .collapse a{
        display: inline-block;
    }
    .collapse a:Hover{
        background-color: lightslategrey;
        font-size: 22px;
        color: black;
    }

    </style>
</head>

<body background="Windows_10_4k_Wallpapers-7.jpg">
<div>
<div class="well">
                <div class="welcome">
                <h4 align="right"><?php echo "Welcome ! "." -". "<b>". $_SESSION['username'] ."</b>" ." "." | ";
						echo '<a href="4-4-16/logout.php">'."<b>LOGOUT</b>" ."</a>";
                ?>
                <h4>
                </div>
			</div>
    <div id="slider">
        <!-- <img src="ragam.gif">-->
       
        <img src="includes/slider-img/nita.png" alt="nita"/>
        <img src="includes/slider-img/nitclt.png" alt="nitclt"/>
      >
    </div>
</div>
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" align="center">
        <li><a href="4-4-16/welcome.php">Dashboard</a></li>
        <li><a href="about.php">About</a></li>
        
        
      </ul>
    </div>
  </div>
</nav>
    <div class="col-sm-12 ">
        <div class="well">
        <marquee direction="left" style="font-size: 16">Online Submission of NIMCET is Open Now</marquee>
        </div>
    </div>
 <div class="col-sm-8 ">
      <div class="well">
        <div class="well">
         <div class="left-side">
	        <marquee direction="up" truespeed>
            <p><h1 id="nimcet-heading" align="center">NIMCET-2016</h1></p>
            <p>NIT MCA COMMON ENTRANCE TEST</p>
	        <p>Admissiono Open </p>
	        <p>Online Submission Is Open Now</p>
	        <p>Exam Date:</p>
	        <p>Download Hall ticket</p>
	        <p>Download Info B.</p>
	        <p>.............</p>
	        <p>Some text..</p>
	        </marquee>
         </div>
       </div>

          <div class="well">
              <div class="left-side">
                  <marquee direction="up" truespeed>
                      <p><h1 id="nimcet-heading" align="center">NIMCET-2016</h1></p>
                      <p>NIT MCA COMMON ENTRANCE TEST</p>
                      <p>Admissiono Open </p>
                      <p>Online Submission Is Open Now</p>
                      <p>Exam Date:</p>
                      <p>Download Hall ticket</p>
                      <p>Download Info B.</p>
                      <p>.............</p>
                      <p>Some text..</p>
                  </marquee>
              </div>
          </div>

      </div>
 </div>

 <div class="col-sm-4 ">
   <div class="well">      
       <ul>
	        <li><h1>Welome !<?php   ?></h1></li>
           <li><p>Read Important Information Before Filling The Information</p></li>
           <li><p>Before Filling application you must insure that you have a Recently taken photograph</p></li>
           <li><p>Photo graph Should be in proper format as Specified in Broucher </p></li>
           <li><p>Date Of photograph taken must be specified </p></li>
           <li><p>No Correction Will Be Allowed After Filling Application</p></li>
           <li><p>Photo graph Should be Clear </p></li>
           <li><p>Read the Declaration Of eligibility carefully and give consent on it before submitting the Form  </p></li>
           <li><a><p>Read More....!</p></a></li>
		</ul>
   </div>
 </div>
<div class="col-sm-12 ">
    <div class="jumbotron">
      <div class="left-side">
         <marquee direction="up" truespeed>
           <p><h1 id="nimcet-heading" align="center">NIMCET-2016</h1></p>
           <p>NIT MCA COMMON ENTRANCE TEST</p>
           <p>Admissiono Open </p>
           <p>Online Submission Is Open Now</p>
           <p>Exam Date:</p>
           <p>Download Hall ticket</p>
           <p>Download Info B.</p>
           <p>.............</p>
           <p>Some text..</p>
         </marquee>
      </div>
    </div>
</div>
<div class="col-sm-12 ">
      <?php include 'footer-header/footer.php'; ?>
</div>
<script type="text/javascript" ></script>
</body>
</html>