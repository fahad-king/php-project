<!--Welcome to my home page : This is Amit Kumar Soni MCA SEM2 NIT Calicut-->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="NIMCET-2016 ,online application submission for MCA entrance; charset=utf-8" />
    <link href="plugins/css/mycss.css" rel="stylesheet" />
    <link href="plugins/css/bootstrap.css" rel="stylesheet" />

    <link href="plugins/css/mycss2.css"  rel="stylesheet" />
	<link href="plugins/css/homepage.css"  rel="stylesheet" />
    <link href="plugins/css/font.css" rel="stylesheet" />
    <link href="plugins/css/container.css" rel="stylesheet" />
    <link href="plugins/css/style.css" rel="stylesheet">
    <link href="footer-header/form-footer-header.css" rel="stylesheet">
    <script type="text/javascript" src="plugins/js/alert.js"></script>
    <script type="text/javascript" src="plugins/js/jquery-2.2.2.js"></script>
    <script type="text/javascript" src="plugins/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="plugins/js/jquery.cycle.all.js"></script>
    <script type="text/javascript">
        $('#slider').cycle({
            //fx:     'fade',
            fx:     'scrollVert',
            speed:  'slow',
            tomeout:.1000
        });
    </script>
    <style>

        .navbar-nav
        {
            text-align: center !important;
            margin-left: 175px;
        }
		td{
			height:50px;
			font-weight:bold;
			text-align:center;
		}
		th{
			height:60px;
			font-size:25px;
			text-align:center;
		}
    </style>
</head>
<!--Body Contains All The content of the web page it is most important to Use this this min tag -->
<body background="Windows_10_4k_Wallpapers-7.jpg">
<div>
    <div id="slider">
        <!-- <img src="ragam.gif">-->
        
        <img src="includes/slider-img/nita.png" alt="nita"/>
        <img src="includes/slider-img/nitclt.png" alt="nitclt"/>
       
    </div>
</div>
<!--Container is the bootstrap DEFIND class Use it to make Your SITE RESPONSIVE -->
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>

    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="home.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="imp_dates.php">important dates</a>
        <li><a href="guied.php">Guidlines</a></li>
        <li><a href="payment_method.php">Payment methods</a></li>
        <li><a href="contact.php">Contact</a></li>
        
      </ul>
    </div>
  </div>
</nav>
    <div class="col-sm-12 ">
        <div class="well">
        <marquee direction="left" style="font-size: 16">Online Submission of NIMCET is Open Now</marquee>
        </div>
    </div>
 <div class="col-sm-12 ">
      <div class="well">
        <div class="well">
         <div class="left-side">
	        <h3 align="center">-=Giudlines =-</h3>
            <h4 align="center">Download Giudlines <a href ="assets/InformationBrochure.pdf">Here</a></h4>
         </div>
       </div>

          <div class="well">
              <div class="left-side">
			  <h2 align="center"><u>Notification</u></h2>
                  <marquee direction="up" truespeed>
                      <p><h1 id="nimcet-heading" align="center">NIMCET-2016</h1></p>
                      <p>NIT MCA COMMON ENTRANCE TEST</p>
                      <p>Admissiono Open </p>
                      <p>Online Submission Is Open Now</p>
                      <p>Exam Date:</p>
                      <p>Download Hall ticket</p>
                      <p>Download Info B.</p>
                      <p>.............</p>
                      <p>Some text..</p>
                  </marquee>
              </div>
          </div>

      </div>
 </div>

<div class="col-sm-12 " style="font-size:18px;text-align:left;color:#330099;font-family:myFirstFont_three; text-align:left">
    <div class="well">
      <div class="left-side">
          <p align="justify">NIT MCA is one of the heighly recognized course in INDIA and also outside
              of india. Course Structure is designed such as per industry requirments.
              MCA Students are most required in outside of india i.e Austrailia Japan USA as well as UK
              National Institute of technology (NITs) are institute
              of national importance and are centrally founded Technical institute .
              Thw NIMCET is a NIT MCA Common Entrance Test .a national level test conducted ny NITs for admissionin to their MCA program
              . The Admission to the MCA Program into NITs  at AGARTALA ALLAHABAD CHOPAL CALICUT DURGAPUR JAMSHEDPUR KURUKSHETRA TRICHY
              and WARANGAL for the year is based on the Rank obtained--
              in NIMCET 2016 ONLY . The curiculum and syllabi of master of
              ComputerApplication (MCA) Program ini NITs are designed consideration
              the need of different information
              Tecnology firm Mca graduates have heighlypotential for jobs in IT sector
          </p>
      </div>
    </div>
</div>
<div class="col-sm-12 ">
      <?php include 'footer-header/footer.php'; ?>
</div>
<script type="text/javascript" ></script>
</body>
</html>