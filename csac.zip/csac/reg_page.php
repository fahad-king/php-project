<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="plugins/css/bootstrap.css">
  <link href="plugins/css/style.css" rel="stylesheet">
  <script src="plugins/js/jquery-2.2.2.js"></script>
  <script src="plugins/js/bootstrap.min.js"></script>
  <style>
  .show-error-in{
	  height:50px;
	  border-bottom:2px solid black;
  }
  </style>
  <script type="text/javascript">
					function validate()
					{
						var emailtxt=document.getElementById(email);
						var email=emailtxt.value;
						var emailReg=/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z]{2,}))$;
						emailtxt.style.color="white";
						if(emailReg.test(email))
						{
							emailtxt.style.backgroundColor="green";
						}
						else{
							
							emailtxt.style.backgroundColor="red";
						}		
					}								
					</script> 
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 		                
      </button>
      
    </div>
	
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        
        <li><a href="home.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="imp_dates.php">important dates</a>
        <li><a href="guied.php">Guidlines</a></li>
        <li><a href="payment_method.php">Payment methods</a></li>
        <li><a href="contact.php">Contact</a></li>
        
      </ul>
      
    </div>
  </div>
</nav>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
      <p><a href="#">Registration Guidlines</a></p>
      <p><a href="#">Payment Status</a></p>
	  <p><a href="#">Broucher</a></p>
      <p><a href="#">Phone Directory</a></p>
      <p><a href="#">imp dates</a></p>
      <p><a href="#">Seat Matrix</a></p>
      <p><a href="#">Contact</a></p>
	  <p><a href="#">Report An Error</a></p>
	  <p><a href="#">About NIT's</a></p>
	  <p><a href="#">FEE Structure </a></p>
    </div>
	
    <div class="col-sm-10 text-left"> 
      <h1 align="center" style="color:#993">Welcome <strong>!</strong> </h1>
      <hr>
	  <!--  Form Starts Here ....-->
      <fieldset>
	   <legend align="center">Student Registration Information</legend>
	      <form action="reg.php" method="POST">
	        <table align="center" width="700px"  >
				<tr>
					<td><label>Name (as 10<sup>th</sup>Marksheet)</label></td>
					<td><input type="text" name="username" required size="30" autofocus></td>			
				</tr>
				<tr>
					<td><label>E-Mail</label></td>
					<td><input type="email" name="email" required autocomplete="off"  id="email" onkeyup="validate()"/></td>	
					
					
				</tr>
				<tr>
					<td><label>Mobile No.</label></td>
					<td><input type="text" name="mobile" required/></td>			
				</tr>
				<tr>
					<td><label>Password</label></td>
					<td><input type="password" name="pass" required size="11"/></td>			
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="save" class="form"></td>			
				</tr>
	       </table>
	     </form>
		 <div align="center" class="show-error-in" >
		 <?php
		 if(isset($_SESSION['username']))
		 {
			  echo "CONGRATULATIONS !" . "<b>" . $_SESSION['username'] ."</b>"."You Are Now Registered..!";
			  session_destroy();
		 }	  
		 ?>
		 </div>
	  </fieldset>
	   <!--  Form Ends Here ....-->	
	  <p align="left">
	  <blockquote>Be Carefull !!<br/>
	  			  <p>
				  <p>Your Username Password is Very Important<p/>
	  			  <p>Dont't Share it with other's</p>	
				  <p>We'll communiacate for any problem Yiu have	via <strong>E-MAIL</strong>
				  so please fill correct e-mail	</p>
				  <p>Don't make Phone call</p>
				  </blockquote></p>
    </div>	  
  </div>
</div>

<p align="justify">NIT MCA is one of the heighly recognized course in INDIA and also outside
	of india. Course Structure is designed such as per industry requirments.
	MCA Students are most required in outside of india i.e Austrailia Japan USA as well as UK
	National Institute of technology (NITs) are institute
	of national importance and are centrally founded Technical institute .
	Thw NIMCET is a NIT MCA Common Entrance Test .a national level test conducted ny NITs for admissionin to their MCA program
	. The Admission to the MCA Program into NITs  at AGARTALA ALLAHABAD CHOPAL CALICUT DURGAPUR JAMSHEDPUR KURUKSHETRA TRICHY
	and WARANGAL for the year is based on the Rank obtained--
	in NIMCET 2016 ONLY . The curiculum and syllabi of master of
	ComputerApplication (MCA) Program ini NITs are designed consideration
	the need of different information
	Tecnology firm Mca graduates have heighlypotential for jobs in IT sector
</p>
<div class="col-sm-12 ">
      <?php include 'footer-header/footer.php'; ?>
</div>
</body>
</html>
