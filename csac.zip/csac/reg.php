<?php 
require ('4-4-16/connect.php');
if(isset($_POST['save']))
{
  session_start();
  $uname =$_POST['username'];
  $email =$_POST['email'];
  $mob_no   =$_POST['mobile'];
  $pw  =$_POST['pass'];
  $uname = strip_tags(mysqli_real_escape_string($con,$_POST['username']));
  $pw = strip_tags(mysqli_real_escape_string($con,$_POST['pass']));
  $search = "SELECT username , mob_no FROM users WHERE username='$uname' and password='$pw' and mob_no='$mob_no'";
  $search_result =mysqli_query($con,$search);
  if(mysqli_query($con,$search))
   {
	 $search_row =mysqli_num_rows($search_result);
	 if($search_row==0)
	 {
		$insert_record="INSERT INTO users(username,email,mob_no,password) VALUES ('$uname','$email','$mob_no','$pw')";
		$insert_record_into_user_table="INSERT INTO `student_detail` (`sname`, `fname`, `cat`, `pwd`, `dob`, `sex`, `tcenter1`, `tcenter2`, `tcenter3`, `email`, `l_phone`, `h_no`, `s_no`, `area`, `po`, `city`, `taluka`, `distt`, `state`, `pin`) VALUES ('$uname', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')";
		if(mysqli_query($con,$insert_record))
		{
		   session_start();
		   $_SESSION['username'] = $uname;
	  	   header('Location:reg_page.php');
		   exit();	
		}
		else
		{
			echo 'insertion Not Done  ';
		}
	 }
	else
	{
		session_destroy();
		header('Location:reg_page.php');
		exit();
	}
  }
}  
 ?>
