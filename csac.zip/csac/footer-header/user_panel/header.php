<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="plugins/css/mycss.css" rel="stylesheet" />
<link href="plugins/css/mycss2.css" rel="stylesheet" />
<script src="plugins/js/jquery-2.2.2.js"></script>
<link href="plugins/css/bootstrap.min.css" rel="stylesheet" />
<link href="plugins/css/bootstrap-theme.min.css" rel="stylesheet" />
</head>

<body>
<?php include 'user_panel/header.php';?>
 <div class="container">
 
 </div>
<?php include 'user_panel/header.php';?>
</body>
</html>