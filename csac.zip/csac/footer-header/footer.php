<head>
	<style>
		.footer{
			line-height: 22px;
			font-size: 22px;
		}
		.footer-social{
			margin-left: 80px;
		}
		.footer-social a{
			font-size: 22px;
			display:inline-block;
			height:43px;
			background-color: lightskyblue;
			text-decoration: none;
			width: 200px;
			border-radius: 10px;
			text-align: center;
			line-height: 43px;
			color: maroon;
			margin: 9px;

		}
		.footer-social a:hover{

			display:inline-block;
			height:43px;
			transition: 1s;
			border-bottom:5px solid deeppink;
			-webkit-transform: rotate(360deg);
			-moz-transform: rotate(360deg);
			-ms-transform: rotate(360deg);
			-o-transform: rotate(360deg);
			transform: rotate(360deg);
			background-color:#2989d8;
			text-decoration: none;
			width: 200px;
			border-radius: 10px;
			text-align: center;
			line-height: 43px;
			color: maroon;
		}

	</style>


</head>
<div class="footer">
	<h4 align="center"><sup>&copy;</sup>Copyright :2010-<?php echo date('y');
										echo "  " . '4M1T_50N1'; ?> </h4>
	
	
	</div>	
<div class="footer-social">
<div class="col-sm-6">

	<table width="824" align="center">
	 <tr>
		<td width="164" height="60" id="footer-td"><a href="#">Privacy Policy</a></td>
		<td width="166" id="footer-td"><a href="#">Refund</a></td>
		<td width="168" id="footer-td"><a href="#">Bank Policies</a></td>
		<td width="68" id="footer-td"><a href="#">Our Vision</a></td>
		<td width="96" id="footer-td"><a href="#">MISC</a></td>
	 </tr>
	 <tr>
		<td height="58" id="footer-td"><a href="#">Help ?</a></td>
		<td id="footer-td"><a href="#">Phone Directory</a></td>
		<td id="footer-td"><a href="#">Site Location</a></td>
		<td id="footer-td"><a href="#">About Us</a></td>
		<td id="footer-td"><a href="#">Developer's</a></td>
	 </tr>
	 <tr>
		<td height="50" id="footer-td"><a href="#">Youtube</a></td>
		<td id="footer-td"><a href="#">Channels</a></td>
		<td id="footer-td"><a href="#">Likes</a></td>
		<td id="footer-td"><a href="#">Count Visitors</a></td>
		<td id="footer-td"><a href="#">Location</a></td>
	 </tr>
	 
	 
  </table>
</div>
	</div>


