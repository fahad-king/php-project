<?php
require ('connect.php');
session_start();
if(!isset($_SESSION['username']))
  {
   if(!isset($_SESSION['username']))
   {
      header('Location:../home.php');
	  exit();
   }
   else{ echo '<a href="logout.php">'."LOGOUT HERE" ."</a>";}
  }
  
  
  if(isset($_POST['save_info']))
  {
	  $sname =$_POST['sname'];
	  $fname =$_POST['fname'];
	  $cat =$_POST['cat'];
	  $pwd =$_POST['pwd'];
	  $dob =$_POST['dob'];
	  $sex =$_POST['sex'];
	  $tcenter1 =$_POST['tc1'];
	  $tcenter2 =$_POST['tc2'];
	  $tcenter3 =$_POST['tc3'];
		$email =$_POST['email'];
		$l_phone =$_POST['l_phone'];
		$h_no =$_POST['h_no'];
		$s_no =$_POST['s_no'];	
		$area =$_POST['village'];
		$po =$_POST['po'];
		$city =$_POST['city'];
		$taluka =$_POST['taluka'];
		$distt =$_POST['district'];
		$state =$_POST['state'];
		$pin =$_POST['pincode'];

      $ins ="INSERT INTO `student_detail` (`sname`, `fname`, `cat`, `pwd`,`dob`, `sex`, `tcenter1`, `tcenter2`, `tcenter3`, `email`, `l_phone`, `h_no`,	  `s_no`, `area`, `po`, `city`, `taluka`, `distt`, `state`, `pin`)VALUES('$sname', '$fname', '$cat', '$pwd', '$dob', '$sex', '$tcenter1', '$tcenter2', '$tcenter3','$email', '$l_phone', '$h_no', '$s_no', '$area', '$po', '$city', '$taluka', '$distt', '$state', '$pin')";		
	  $ins_result =mysqli_query($con,$ins);
      if($ins_result)
	  {
		  $_SESSION['hogya'] = "ALL INFORMATION YOU HAVE ENTERED IS SAVED";
	  }
		else{
		echo "NOT DONE";	
		}
		
	  
  }
  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>New Registration</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="../plugins/css/bootstrap.css" rel="stylesheet" />
    <link href="../plugins/css/style.css" rel="stylesheet">
    <script type="text/javascript" src="../plugins/js/jquery-2.2.2.js"></script>
    <script type="text/javascript" src="../plugins/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../plugins/js/jquery.cycle.all.js"></script>

    <script type="text/javascript">
        $('#slider').cycle({
            //fx:     'fade',
            fx:     'scrollHorz',
            speed:  'slow',
            tomeout:.1000
        });
    </script>
	<style>
	td{
		text-align:left;
	}
	</style>
    
</head>

<body background="Windows_10_4k_Wallpapers-7.jpg">
			<div class="well">
                <div class="welcome">
                <h4 align="right"><?php echo "Welcome ! "." -". "<b>". $_SESSION['username'] ."</b>" ." "." | ";
						echo '<a href="logout.php">'."<b>LOGOUT</b>" ."</a>";
                ?>
                <h4>
                </div>
			</div>
<div>
    <div id="slider">
        <!-- <img src="ragam.gif">-->
        <img src="../includes/slider-img/jnu.png" alt="jnu"/>
        <img src="../includes/slider-img/nita.png" alt="nita"/>
        <img src="../includes/slider-img/nitclt.png" alt="nitclt"/>
        <img src="../includes/slider-img/nitjsr.png" alt="nitjsr"/>
        <img src="../includes/slider-img/nitw.png" alt="nitw"/>
        <img src="../includes/slider-img/nitrr.png" alt="nitrr"/>
        <img src="../includes/slider-img/nitw.png" alt="nitw"/>
        <img src="../includes/slider-img/nitw2.png" alt="nitw2"/>
    <img src="../includes/slider-img/nitww.png" alt="nitww"/><img src="../includes/slider-img/nitw.png" alt="nitw"/></div>
</div>
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="home.php">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="impdates.html">important dates</a>
        <li><a href="guide.html">Guidlines</a></li>
        <li><a href="pay_method.html">Payment methods</a></li>
        <li><a href="contact.html">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>
    <div class="col-sm-12 ">
        <div class="well">
        <marquee direction="left" style="font-size: 16 color:red"><?php echo "Welcome ! "." -". "<b>". $_SESSION['username'] ."</b>" ?></marquee>
        
    </div>
<div class="jumbotron ">
   <div class="well" style="color:red ;tect-align:center;">
   <?php
     if(isset($_POST['save_info']))
	 {
		 echo $_SESSION['hogya'] ."<br/>"; 
	 }
   
   ?>
   <a href="welcome.php">&larr;take me back </a>
   </div>
   <frameset>
   <legend align="center">Personal Info</legend>
	<form action="new-application.php" method="post">
	 <table height="563" align="center">
	   <tr>
		 <td > NAME:</td>
		 <td ><input type="text" name="sname" required /></td>
		</tr>
		<tr>
		  <td >Mothers's Name:</td>
		  <td><input type="text" name="fname" required/></td>
		 </tr>
		 <tr>
		   <td >Category</td>
		   <td><input type="text" name="cat" required/></td>
		 </tr>
		 <tr>
			<td >Person With Disability</td>
			<td><input type="text" name="pwd" required/></td>
		 </tr>
		 <tr>
			<td >Date Of Birth </td>
		 	<td><input type="date" name="dob" required/ max="1992-01-01"></td>
		 </tr>
		 <tr>
			<td >Sex</td>
			<td><input type="radio" name="sex" required/ maxlength="1">male
				<input type="radio" name="sex" required/>female
			</td>
		  </tr>
		  <tr>
		  	 <td>Choose Test Center 1</td>
			 <td>
			 <input type="text" name="tc1" required/></td>
		  </tr>
		  <tr>
		  	 <td>Choose Test Center 2</td>
			 <td><input type="text" name="tc2" /></td>
		  </tr>
		  <tr>
		  	 <td>Choose Test Center 3</td>
			 <td><input type="text" name="tc3" /></td>
		  </tr>
		  <tr>
		  	 <td>EMail ID</td>
			 <td><input type="mail" name="email" required/></td>
			 <script type="text/javascript">
					function validate()
					{
						var emailtxt=document.getElementById(email);
						var email=emailtxt.value;
					var emailReg=/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z]{2,}))$;
					emailtxt.style.color="white";
						if(emailReg.test(email))
						{
							emailtxt.style.backgroundColor="green";
						}
						else{
							
							emailtxt.style.backgroundColor="red";
						}
							
					}
										
					</script>
		  </tr>
		  <tr>
		  	 <td>Landline Phone NUMBER</td>
			 <td><input type="text" name="l_phone" maxlength="10"/></td>
		  </tr>
		  <tr>
		  	 <td>House Number </td>
			 <td><input type="text" name="h_no" maxlength="5" /></td>
		  </tr>
		  <tr>
		  	 <td>Street Number</td>
			 <td><input type="text" name="s_no" /></td>
		  </tr>
		  <tr>
		  	 <td>area/Village</td>
			 <td><input type="text" name="village" required/></td>
		  </tr>
		  <tr>
		  	 <td>Post Office</td>
			 <td><input type="text" name="po" required/></td>
		  </tr>
		  <tr>
		  	 <td>City Town</td>
			 <td><input type="text" name="city" /></td>
		  </tr>
		  <tr>
		  	 <td>Taluka/Tahsil</td>
			 <td><input type="text" name="taluka" /></td>
		  </tr>
		  <tr>
		  	 <td>District</td>
			 <td><input type="text" name="district"required /></td>
		  </tr>
		  <tr>
		  	 <td>State</td>
			 <td><input type="text" name="state" /></td>
		  </tr>
		  <tr>
		  	 <td>PINCODE</td>
			 <td><input type="text" name="pincode" required maxlength="5"/></td>
		  </tr>
		  
		  <tr>
		  	 <td></td>
			 <td><button type="submit" name="save_info" class="btn btn-default"/>proceed<span class="glyphicon glyphicon-apple"></span></button></td>
		  </tr>
		</table>		
	  </form>
	 </frameset> 
 </div>
</div>
<div class="col-sm-12 ">
      <?php include '../footer-header/footer.php'; ?>
</div>
</body>
</html>
