<?php
require ('connect.php');
session_start();
if(!isset($_SESSION['username']))
  {
   if(!isset($_SESSION['username']))
   {
      header('Location:../home.php');
	  exit();
   }
   else{ echo '<a href="logout.php">'."LOGOUT HERE" ."</a>";}
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Welcome </title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="../plugins/css/bootstrap.css" rel="stylesheet" />
    <link href="../plugins/css/style.css" rel="stylesheet">
    <script type="text/javascript" src="../plugins/js/jquery-2.2.2.js"></script>
    <script type="text/javascript" src="../plugins/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../plugins/js/jquery.cycle.all.js"></script>

    <script type="text/javascript">
        $('#slider').cycle({
            //fx:     'fade',
            fx:     'scrollHorz',
            speed:  'slow',
            tomeout:.1000
        });
    </script>
    
</head>

<body background="../Windows_10_4k_Wallpapers-7.jpg">
			<div class="well">
                <div class="welcome">
                <h4 align="right"><?php echo "Welcome ! "." -". "<b>". $_SESSION['username'] ."</b>" ." "." | ";
						echo '<a href="logout.php">'."<b>LOGOUT</b>" ."</a>";
                ?>
                <h4>
                </div>
			</div>
<div>
    <div id="slider">
        <!-- <img src="ragam.gif">-->
       
        <img src="../includes/slider-img/nita.png" alt="nita"/>
        
    </div>
</div>
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="../home.php">Home</a></li>
        
      </ul>
    </div>
  </div>
</nav>
    <div class="col-sm-12 ">
        <div class="row well">
           <?php echo "Welcome ! "." -". "<b>". $_SESSION['username'] ."</b>" ?>
        </div>
	</div>	
 <div class="col-sm-8 ">
      <div class="well">
        <div class="well">
         <div class="left-side">

            <p><h1 id="nimcet-heading" align="center">NIMCET-2016</h1></p>
            <p>NIT MCA COMMON ENTRANCE TEST</p>
	        <p><a href="new-application.php">Fillup Application </a></p>
	        <p><a href="#">Check staus</a></p>
			<p>
				<form action="show_record.php" method="POST" align="center">
				    <input type="submit" name="show" value="Display">
				</form>
			</p>
			
	        <p>Exam Date: 25-may-2016</p>
	        <p><a href="#">Download Hall ticket</a></p>
	        <p><a href="#">Download Info B.</a></p>
	        <p><a href="#">change password</a></p>
	        <p></p>

         </div><!--  left-side  ends here -->
       </div><!--  WELL CLASS  ends here -->

          <div class="well">
              <div class="left-side">
                <h3 class="subtitle" align="center">User Details</h3>
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover table-bordered" border="1">
                      <?php
					  if(isset($_POST['show']))
						{	  
							   $temp_user= $_SESSION['username'];
							   //$temp_user2 =$_POST['ssname'];
							   //if($temp_user===$temp_user2)
							      
								   $disp_var ="SELECT * FROM student_detail WHERE sname ='$temp_user'";
								   $disp_again =mysqli_query($con,$disp_var);
								   $result_count =mysqli_num_rows($disp_again);
								   if($result_count>0)
								   {
										while ($row = mysqli_fetch_assoc($disp_again))
										{
										?>
											 <tr><td>NAME					</td><td><?php echo $row['sname']; ?></td></tr>
											 <tr><td>Mothers Name			</td><td><?php echo $row['fname']; ?></td></tr>
											 <tr><td>Category				</td><td><?php echo $row['cat']; ?>  </td></tr>
											 <tr><td>Person With Disability </td><td><?php echo $row['pwd']; ?>  </td></tr>
											 <tr><td>Date Of Birth			</td><td><?php echo $row['dob']; ?>  </td></tr>
											 <tr><td>Gender					</td><td><?php echo $row['sex']; ?>  </td></tr>
											 <tr><td>Test Center 1 			</td><td><?php echo $row['tcenter1'];?></td></tr>
											 <tr><td>Test Center 2:			</td><td><?php echo $row['tcenter2'];?></td></tr>
											 <tr><td>Test Center 2			</td><td><?php echo $row['tcenter3'];?></td></tr>
											 <tr><td>Email					</td><td><?php echo $row['email']; ?>  </td></tr>
											 <tr><td>Landline Number :		</td><td><?php echo $row['l_phone'];?> </td></tr>
											 <tr><td>House Number :			</td><td><?php echo $row['h_no']; ?>   </td></tr>
											 <tr><td>Street Number :		</td><td><?php echo $row['s_no']; ?>   </td></tr>
											 <tr><td>Area :					</td><td><?php echo $row['area']; ?>   </td></tr>
											 <tr><td>Post Office			</td><td><?php echo $row['po']; ?>     </td></tr>
											 <tr><td>Nearest City			</td><td><?php echo $row['city']; ?>   </td></tr>
											 <tr><td>Taluka :				</td><td><?php echo $row['taluka']; ?>  </td></tr>
											 <tr><td>District				</td><td><?php echo $row['distt']; ?>   </td></tr>
											 <tr><td>State					</td><td><?php echo $row['state']; ?>   </td></tr>
											 <tr><td>pincode				</td><td><?php echo $row['pin']; ?>     </td></tr>
										<?php
										}
								   }							   
								else
								{
								?>
								<p align="center">
								<?php echo "Please Enter you username that you have used to LOGIN</p>";
								}	
						}
						else{
							?>
							<p align="center">
							<?php echo "Please Enter You Name To Show Your Information</p>"; 
						}
                       ?>
                    </table>
                </div>
              </div>
          </div><!-- WELL CLASS ENDS HERE-->
      </div><!--col-sm-8 FIRST WELL CLASS ENDS HERE-->
 </div><!--col-sm-8 CLASS ENDS HERE-->

 <div class="col-sm-4 ">
   <div class="well">      
       <ul>
	        <li><h1>Attension !<?php echo " - ".$_SESSION['username'];   ?></h1></li>
           <li><p>Read Important Information Before Filling The Information</p></li>
           <li><p>Before Filling application you must insure that you have a Recently taken photograph</p></li>
           <li><p>Photo graph Should be in proper format as Specified in Broucher </p></li>
           <li><p>Date Of photograph taken must be specified </p></li>
           <li><p>No Correction Will Be Allowed After Filling Application</p></li>
           <li><p>Photo graph Should be Clear </p></li>
           <li><p>Read the Declaration Of eligibility carefully and give consent on it before submitting the Form  </p></li>
           <li><a><p>Read More....!</p></a></li>
		</ul>
   </div>
 </div>
<div class="col-sm-12 ">
    <div class="jumbotron">
      <div class="left-side">
         
           <p><h1 id="nimcet-heading" align="center">NIMCET-2016</h1></p>
           <p>NIT MCA COMMON ENTRANCE TEST</p>
           <p>.............</p>
		   <p>Admissiono Open </p>
           <p>.............</p>
		   <p>Online Submission Is Open Now</p>
           <p>.............</p>
		   <p>Exam Date:25-may-2016</p>
           <p>.............</p>
		   <p>Download Hall ticket...NOT AVAILABLE YET</p>
           <p>.............</p>
		   <p>Download Info B.</p>
         
      </div>
    </div>
</div>
<div class="col-sm-12 ">
      <?php include '../footer-header/footer.php'; ?>
</div>
<script type="text/javascript" ></script>
</body>
</html>
