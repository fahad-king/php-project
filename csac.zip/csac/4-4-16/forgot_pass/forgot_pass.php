 <?php session_start();?>
 
 <!--Welcome to my home page : This is Amit Kumar Soni MCA SEM2 NIT Calicut-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>    
    <link href="../../plugins/css/bootstrap.css" rel="stylesheet" />
    <link href="../../plugins/css/style.css" rel="stylesheet">
    <script type="text/javascript" src="../../plugins/js/jquery-2.2.2.js"></script>
    <script type="text/javascript" src="../../plugins/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../../plugins/js/jquery.cycle.all.js"></script>
    <style>
		   .navbar-nav
			{
			  text-align: center !important;
			  margin-left: 175px;
			}
			.show-error-in
			{
			height:50px;
			border-bottom:2px solid black;
			}
			input[type="submit"]
			{
				height:30px;
				font-size:20px;
			}
				
    </style>
</head>
<!--Body Contains All The content of the web page it is most important to Use this this min tag -->
<body background="../../Windows_10_4k_Wallpapers-7.jpg">

<!--Container is the bootstrap DEFIND class Use it to make Your SITE RESPONSIVE -->
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>

    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="../../home.php">Home</a></li>
        <li><a href="../../about.html">About</a></li>
        <li><a href="../../impdates.html">important dates</a>
        <li><a href="../../guide.html">Guidlines</a></li>
        <li><a href="../../pay_method.html">Payment methods</a></li>
        <li><a href="../../contact.html">Contact</a></li>
        
      </ul>
    </div>
  </div>
</nav>
    <div class="col-sm-12 ">
        <div class="well">
        <marquee direction="left" style="font-size: 16">Welcome to Password recovery System</marquee>
        </div>
    </div>
 <div class="col-sm-8 ">
      <div class="well">
        <div class="well">
         <div class="left-side">
	        
            <p><h1 id="nimcet-heading" align="center">NIMCET-2016</h1></p>
            <p>NIT MCA COMMON ENTRANCE TEST</p>
	        <p>Welcome You User </p>
	        <p>Password In Most Important stuff </p>
	        <p>never share it with any one </p>
	        <p>It is totally your prorety</p>
	        <p>would you want to loose your things???</p>
	        <p>.............</p>
	        <p>Abolutely No...</p>
	       
         </div>
       </div>
      </div>
 </div>

 <div class="col-sm-4 ">
   <div class="well"">
       <fieldset>
	   <legend align="center">Password Recovery Portal</legend>
	      <form action="forgot_pass.php" method="POST">
	        <table align="center">
				<tr>
					<td><label>Name</label></td>
					<td><input type="text" name="username" required></td>			
				</tr>
				<tr>
				    <td><label>Mobile No.</label></td>
					<td><input type="text" name="mobile" required></td>			
				</tr>			
	       </table>
		   <br/>
		   <p align="center" style="margin-left:39px"><input type="submit" name="save" value="SHOW " class="btn btn-danger"></p>
	      </form>
		 </fieldset>
		 
		 <div align="center" class="show-error-in" >
		 <?php
		 if(isset($_POST['save']))
		 {
			  $temp_uname = $_POST['username'];
			  $temp_mob_no   = $_POST['mobile']; 	
			  include ('../connect.php');
			  $recover_pass = "SELECT password FROM users WHERE username ='$temp_uname' AND mob_no='$temp_mob_no'";
			  $result=$con->query($recover_pass);
			  if ($result->num_rows==1)
			  {
				while($row = $result->fetch_assoc())
				{
				  echo "Password: " . $row["password"];
				  session_destroy(); 
				}
			  }
			  else
			  {
				 
				echo "OOPS! no one is registered at that password !";
				session_destroy(); 
			  }
		 } 
		 ?>
		 </div>		       
   </div>
 </div>

<div class="col-sm-12 ">
      
</div>
<script type="text/javascript" ></script>
</body>
</html>
 