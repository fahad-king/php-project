<?php
require ('connect.php');
if(isset($_POST['save']))
{
    $uname = strip_tags(mysqli_real_escape_string($con,$_POST['username']));
    $passw = strip_tags(mysqli_real_escape_string($con,$_POST['pass']));
    $query ="SELECT username from users where username='$uname' AND password='$passw'";
    $query_run =mysqli_query($con,$query);
	$row;
    if($query_run)
    {
        $row =mysqli_num_rows($query_run);
    }
    if($row ==0)
    {
        echo 'Incorrect Username Password ';
    }
    else{
        session_start();
        $_SESSION['username'] =$uname;
        $_SESSION['password'] =$passw;
        header('location:welcome.php');
        exit();
    }
}
?>