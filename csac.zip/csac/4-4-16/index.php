<Doctype html>
<html>
<head>
    <link rel="stylesheet" href="css/mystyle.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-2.2.2.js"></script>
    <title>Login Testing</title>
	
</head>

<body>
<?php include('includes/general-header.php');?>
<p>MAIN BODY OF THE PAGE </p>
<table>
    <tr>

    </tr>
</table>

<?php include('includes/general-footer.php');?>
</body>
</html>