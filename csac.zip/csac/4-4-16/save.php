<?php
require ('connect.php');
session_start();
if(!isset($_SESSION['username']))
  {
   if(!isset($_SESSION['username']))
   {
      header('Location:../home.php');
	  exit();
   }
   else{ echo '<a href="logout.php">'."LOGOUT HERE" ."</a>";}
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>New Registration</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="css/mycss.css" rel="stylesheet" />
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/bootstrap-theme.min.css" rel="stylesheet" />
    <link href="css/mycss2.css"  rel="stylesheet" />
    <link href="css/font.css" rel="stylesheet" />
    <link href="css/container.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
    <link href="css/footer-header/form-footer-header.css" rel="stylesheet">
    <script type="text/javascript" src="js/alert.js"></script>
    <script type="text/javascript" src="js/jquery-2.2.2.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.cycle.all.js"></script>

    <script type="text/javascript">
        $('#slider').cycle({
            //fx:     'fade',
            fx:     'scrollHorz',
            speed:  'slow',
            tomeout:.1000
        });
    </script>
    <style>
    .container {
        border-radius: 2px;
       //background-color: #5bc0de;
    }
     #slider{
         margin-left: 30px;
         margin-right: 30px;
         margin-top: 10px;
         margin-bottom: 2px;
         -webkit-border-radius: 30px;
         -moz-border-radius: 30px;
         border-radius: 30px !important;
     }
    .left-side p{
            text-align: center;
     }
    .collapse {
        background-color: #23527c; !important;
    }
    .collapse a{
        display: inline-block;
    }
    .collapse a:Hover{
        background-color: lightslategrey;
        font-size: 22px;
        color: black;
    }
    .nav ul li{
        text-align: center;
    }
	p{
		text-align:left;
	}
	.jumbotron input{
		width:auto;
	}
	td{
		height:39px;
		width:300px;
		font-size:18px;
	}

    </style>
</head>

<body background="Windows_10_4k_Wallpapers-7.jpg">
			<div class="well">
                <div class="welcome">
                <h4 align="right"><?php echo "Welcome ! "." -". "<b>". $_SESSION['username'] ."</b>" ." "." | ";
						echo '<a href="logout.php">'."<b>LOGOUT</b>" ."</a>";
                ?>
                <h4>
                </div>
			</div>
<div>
    <div id="slider">
        <!-- <img src="ragam.gif">-->
        <img src="../includes/slider-img/jnu.png" alt="jnu"/>
        <img src="../includes/slider-img/nita.png" alt="nita"/>
        <img src="../includes/slider-img/nitclt.png" alt="nitclt"/>
        <img src="../includes/slider-img/nitjsr.png" alt="nitjsr"/>
        <img src="../includes/slider-img/nitw.png" alt="nitw"/>
        <img src="../includes/slider-img/nitrr.png" alt="nitrr"/>
        <img src="../includes/slider-img/nitw.png" alt="nitw"/>
        <img src="../includes/slider-img/nitw2.png" alt="nitw2"/>
    <img src="../includes/slider-img/nitww.png" alt="nitww"/><img src="../includes/slider-img/nitw.png" alt="nitw"/></div>
</div>
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="home.php">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="impdates.html">important dates</a>
        <li><a href="guide.html">Guidlines</a></li>
        <li><a href="pay_method.html">Payment methods</a></li>
        <li><a href="contact.html">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>
    <div class="col-sm-12 ">
        <div class="well">
        <marquee direction="left" style="font-size: 16 color:red"><?php echo "Welcome ! "." -". "<b>". $_SESSION['username'] ."</b>" ?></marquee>
        
    </div>
<div class="jumbotron ">
   <frameset>
   <legend align="center">Personal Info</legend>
	<form action="new-application.php" method="post">
	 <table height="563" align="center">
	   <tr>
		 <td ><h4> NAME:</h4></td>
		 <td ><input type="text" name="sname" /></td>
		</tr>
		<tr>
		  <td ><h4>Mothers's Name:</h4></td>
		  <td><input type="text" name="fname" /></td>
		 </tr>
		 <tr>
		   <td ><h4>Category</h4></td>
		   <td><input type="text" name="cat" /></td>
		 </tr>
		 <tr>
			<td ><strong>Person With Disability</strong></td>
			<td><input type="text" name="pwd" /></td>
		 </tr>
		 <tr>
			<td >Date Of Birth </td>
		 	<td><input type="datet" name="dob" /></td>
		 </tr>
		 <tr>
			<td >Sex</td>
			<td><input type="radio" name="sex" />male
				<input type="radio" name="sex" />female
			</td>
		  </tr>
		  <tr>
		  	 <td>Choose Test Center 1</td>
			 <td>
			 <input type="text" name="name" /></td>
		  </tr>
		  <tr>
		  	 <td>Choose Test Center 2</td>
			 <td><input type="text" name="name" /></td>
		  </tr>
		  <tr>
		  	 <td>Choose Test Center 3</td>
			 <td><input type="text" name="name" /></td>
		  </tr>
		  <tr>
		  	 <td>EMail ID</td>
			 <td><input type="mail" name="email" /></td>
		  </tr>
		  <tr>
		  	 <td>Landline Phone NUMBER</td>
			 <td><input type="text" name="l_phone" /></td>
		  </tr>
		  <tr>
		  	 <td>House Number </td>
			 <td><input type="text" name="h_no" /></td>
		  </tr>
		  <tr>
		  	 <td>Street Number</td>
			 <td><input type="text" name="s_no" /></td>
		  </tr>
		  <tr>
		  	 <td>area/Village</td>
			 <td><input type="text" name="village" /></td>
		  </tr>
		  <tr>
		  	 <td>Post Office</td>
			 <td><input type="text" name="po" /></td>
		  </tr>
		  <tr>
		  	 <td>City Town</td>
			 <td><input type="text" name="city" /></td>
		  </tr>
		  <tr>
		  	 <td>Taluka/Tahsil</td>
			 <td><input type="text" name="taluka" /></td>
		  </tr>
		  <tr>
		  	 <td>District</td>
			 <td><input type="text" name="district" /></td>
		  </tr>
		  <tr>
		  	 <td>State</td>
			 <td><input type="text" name="state" /></td>
		  </tr>
		  <tr>
		  	 <td>PINCODE</td>
			 <td><input type="text" name="pincode" /></td>
		  </tr>
		  
		  <tr>
		  	 <td></td>
			 <td><input type="submit" name="save_info" value="save and proceed"/></td>
		  </tr>
		</table>		
	  </form>
	 </frameset> 
 </div>
</div>
</body>
</html>
