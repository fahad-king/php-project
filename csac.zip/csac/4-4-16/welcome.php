<?php
session_start();
   if(!isset($_SESSION['username']))
   {
      header('Location:../home.php');
	  exit();
   }
   else{ echo '<a href="logout.php">'."LOGOUT HERE" ."</a>";}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Welcome </title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="../plugins/css/bootstrap.css" rel="stylesheet" />
    <link href="../plugins/css/style.css" rel="stylesheet">
    <script type="text/javascript" src="../plugins/js/jquery-2.2.2.js"></script>
    <script type="text/javascript" src="../plugins/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../plugins/js/jquery.cycle.all.js"></script>

    <script type="text/javascript">
        $('#slider').cycle({
            //fx:     'fade',
            fx:     'scrollHorz',
            speed:  'slow',
            tomeout:.1000
        });
    </script>
    
</head>

<body background="Windows_10_4k_Wallpapers-7.jpg">
			<div class="row">	
                <div class="well">
                <h4 align="right"><?php echo "Welcome ! "." -". "<b>". $_SESSION['username'] ."</b>" ." "." | ";
						echo '<a href="logout.php">'."<b>LOGOUT</b>" ."</a>";
                ?>
                <h4>
                </div>
			</div>
<div>
    <div id="slider">
        <!-- <img src="ragam.gif">-->
       
        <img src="../includes/slider-img/nita.png" alt="nita"/>
        <img src="../includes/slider-img/nitclt.png" alt="nitclt"/>
        
      
    </div>
</div>
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="../home.php">Home</a></li>
        <li><a href="../imp_dates.php">important dates</a>
        <li><a href="../contact.php">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>
    <div class="col-sm-12 ">
        <div class="well">
        <marquee direction="left" style="font-size: 16 color:red"><?php echo "Welcome ! "." -". "<b>". $_SESSION['username'] ."</b>" ?></marquee>
        
    </div>
 <div class="col-sm-8 ">
      <div class="well">
        <div class="well">
         <div class="left-side">

            

         </div>
       </div>

        <div class="well">
         <div class="left-side">
            <p><h1 id="nimcet-heading" align="center">NIMCET-2016</h1></p>
            <p>NIT MCA COMMON ENTRANCE TEST</p>
            <div class="well"><p>Admissiono Open </p></div>
            <div class="well"><p>Online Submission Is Open Now</p></div>
            <div class="well"><p>Exam Date:</p></div>
            <div class="well"><p><a href="#">Download Hall ticket</a></p></div>
            <div class="well"><p><a href="../assets/InformationBrochure.pdf">Download Info Broucher</a></p></div>
			<div class="well"><p><a href="show_record.php">Show My Information</a></p></div>
            <div class="well"><p>.............</p></div>
			<div class="well"><p><a href="../assets/paymentdetails.pdf">Guidlines</a></p></div>
			<div class="well"><p><a href="../assets/InformationBrochure.pdf">Information Broucher</a></p></div>
            <div class="well"><p >Some text..</p></div>
        </div>
      </div>

      </div>
 </div>

 <div class="col-sm-4 ">
   <div class="well">      
       <ul>
	        <li><h1>Attention !<?php echo " - ".$_SESSION['username'];   ?></h1></li>
           <li><p>Read Important Information Before Filling The Information</p></li>
           <li><p>Before Filling application you must insure that you have a Recently taken photograph</p></li>
           <li><p>Photo graph Should be in proper format as Specified in Broucher </p></li>
           <li><p>Date Of photograph taken must be specified </p></li>
           <li><p>No Correction Will Be Allowed After Filling Application</p></li>
           <li><p>Photo graph Should be Clear </p></li>
           <li><p>Read the Declaration Of eligibility carefully and give consent on it before submitting the Form  </p></li>
           <li><a><p>Read More....!</p></a></li>
		</ul>
   </div>
 </div>
<div class="col-sm-12 ">
    <div class="jumbotron">
      <div class="left-side">
         <marquee direction="up" truespeed>
           <p><h1 id="nimcet-heading" align="center">NIMCET-2016</h1></p>
           <p>NIT MCA COMMON ENTRANCE TEST</p>
           <p>Admissiono Open </p>
           <p>Online Submission Is Open Now</p>
           <p>Exam Date:</p>
           <p>Download Hall ticket</p>
           <p>Download Info B.</p>
           <p>.............</p>
           <p>Some text..</p>
         </marquee>
      </div>
    </div>
</div>
<div class="col-sm-12 ">
      <?php include '../footer-header/footer.php'; ?>
</div>
<script type="text/javascript" ></script>
</body>
</html>
