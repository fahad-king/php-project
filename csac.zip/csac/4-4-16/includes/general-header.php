<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Case</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/mystyle.css">
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery-2.2.2.js"></script>
</head>
<body>
   <div class="wellcome well-sm ">
        <form action="login.php" method="post">
            <table id="login-table">
                <tr>
                    <td><b>User Name :</b></td>
                    <td>&nbsp;&nbsp;<input type="text" name="username" required="required"></td>
                    <td>&nbsp;&nbsp;<b>PassWord:</b></td>
                    <td>&nbsp;&nbsp;<input type="password" name="pass" required="required"></td>
                    <td></td>
                    <td>&nbsp;&nbsp;<input type="submit" name="save" value="Login" class=".btn-success"></td>
                </tr>
            </table>
        </form>
    <!--  Form End here .........-->
    </div> 
    <div id="slider">
            <p>slider</p>
            <p>slider</p>
            <p>slider</p>
            <p>slider</p>
            <p>slider</p>
            <p>slider</p>
    </div>

<div class="container">
    <p>Hello thiss sIs Th eContaoner </p>
</div>
</body>
</html>