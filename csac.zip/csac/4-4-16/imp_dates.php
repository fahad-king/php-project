<!--Welcome to my home page : This is Amit Kumar Soni MCA SEM2 NIT Calicut-->
<?php
require ('connect.php');

session_start();
if(isset($_SESSION['username']))
  {
     
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Home</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="NIMCET-2016 ,online application submission for MCA entrance; charset=utf-8" />
    <link href="../plugins/css/mycss.css" rel="stylesheet" />
    <link href="../plugins/css/bootstrap.css" rel="stylesheet" />

    <link href="../plugins/css/mycss2.css"  rel="stylesheet" />
	<link href="../plugins/css/homepage.css"  rel="stylesheet" />
    <link href="../plugins/css/font.css" rel="stylesheet" />
    <link href="../plugins/css/container.css" rel="stylesheet" />
    <link href="../plugins/css/style.css" rel="stylesheet">
    <link href="../footer-header/form-footer-header.css" rel="stylesheet">
    <script type="text/javascript" src="../plugins/js/alert.js"></script>
    <script type="text/javascript" src="../plugins/js/jquery-2.2.2.js"></script>
    <script type="text/javascript" src="../plugins/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../plugins/js/jquery.cycle.all.js"></script>
    <script type="text/javascript">
        $('#slider').cycle({
            //fx:     'fade',
            fx:     'scrollVert',
            speed:  'slow',
            tomeout:.1000
        });
    </script>
    <style>

        .navbar-nav
        {
            text-align: center !important;
            margin-left: 175px;
        }
		td{
			height:50px;
			font-weight:bold;
			text-align:center;
		}
		th{
			height:60px;
			font-size:25px;
			text-align:center;
		}
    </style>
</head>
<!--Body Contains All The content of the web page it is most important to Use this this min tag -->
<body background="Windows_10_4k_Wallpapers-7.jpg">
<div>
    <div id="slider">
        <!-- <img src="ragam.gif">-->
        
        <img src="../includes/slider-img/nita.png" alt="nita"/>
        <img src="../includes/slider-img/nitclt.png" alt="nitclt"/>
       
    </div>
</div>
<!--Container is the bootstrap DEFIND class Use it to make Your SITE RESPONSIVE -->
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>

    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="../home.php"">Home</a></li>
        <li><a href="../about.php">About</a></li>
        <li><a href="imp_dates.php">important dates</a>
        <li><a href="../guied.php">Guidlines</a></li>
        <li><a href="#">Payment methods</a></li>
        <li><a href="../contact.php">Contact</a></li>
        
      </ul>
    </div>
  </div>
</nav>
    <div class="col-sm-12 ">
        <div class="well">
        <marquee direction="left" style="font-size: 16">Online Submission of NIMCET is Open Now</marquee>
        </div>
    </div>
 <div class="col-sm-8 ">
      <div class="well">
        <div class="well">
         <div class="left-side">
	        <h2 align="center">-=IMPORTANT DATES =-</h2>
             <table width="800" border="1">
					<tr>
						<th>Events</th>
						<th>Dates</th>
					</tr>
					<tr>
						<td>Publication of Advertisement in Press and Web</td>
						<td>Wednesday, 1st March, 2016</td>
					</tr>
					<tr>
						<td>Opening date for online Registration and Filling of Online Application form</td>
						<td>Friday 3rd March, 2016   </td>
					</tr>
					<tr>
						<td>Last date for receipt of printout of electronically filled application form along with self-attested copy of Marks sheet of Class- 12 and Graduation certificate with payment receipt by speed post/ Registered pos</td>
						<td>Monday, 18th April, 2016 [3P.M]</td>
					</tr>
					<tr>
						<td>Availability of Admit card on NIT, Durgapur website http://nimcet2016.nitdgp.ac.in for download </td>
						<td>Monday 16th May 2016 onwards</td>
					</tr>
					<tr>
						<td>Date and Time of Examination</td>
						<td>Sunday, 29th May 2016 Time: 10 A.M to 12 Noon.</td>
					</tr>
					<tr>
						<td>Opening date of On-Line Choice filling</td>
						<td>Friday 10th June, 2016
10 A.M onwards            </td>
					</tr>
					<tr>
						<td>Closing date of On line Choice filling</td>
						<td>Wednesday, 15th June,2016</td>
					</tr>
					<tr>
						<td>First Round Seat Allotment</td>
						<td>Saturday 18th June, 2016</td>
					</tr>
					<tr>
						<td>First round of Remote reporting in person in any of the counseling centre i.e. participating NITs offering MCA Programme</td>
						<td>Wednesday 22nd June to Friday 24th June, 2016, 10 A.M to 5 P.M./td>
					</tr>
					
					<tr>
					    <td>Second round of Allotment/up gradation</td>
						<td>Wednesday, 29th June, 2016.</td>
					</tr>

					<tr>
					    <td>Second round of Remote reporting in person (fresh allotees and allotees whose seats are upgraded, but need to modify after their option)</td>
						<td>Friday 1st and Saturday 2nd July, 2016.
10 A.M to 5 P.M</td>
					</tr>

						<tr>
					    <td>Third round of allotment/upgradation</td>
						<td>Friday 8th  July, 2016</td>
					</tr>
					
					<tr>
					    <td>Third round of reporting in person at the allotted institute</td>
						<td>Thursday 14th to Friday 15th July 2016
Time 10 A.M to 5 P.M</td>
					</tr>

                    <tr>
					    <td>Surrendering the allotted seats in person through participating counseling centre by those who do not wish to join the allotted institute, but wish to participate against vacant seat, if any.</td>
						<td>Monday 18th to Tuesday 19th July 2016
Time 10 A.M to 5 P.M</td>
					</tr>
					<tr>
					    <td>Announcement of vacant seats</td>
						<td>Thursday 16th July 2016</td>
					</tr>
					
					<tr>
					    <td>Fresh Choice Filling in person against vacant seat, if any, through any of the counseling centre</td>
						<td>Saturday 23rd to Sunday 24th July, 2016
Time 10 A.M to 5 P.M</td>
					</tr>
					
					<tr>
					    <td>Final round of allotment of vacant seat, if any</td>
						<td>Tuesday 26th July 2016</td>
					</tr>
					
					<tr>
					    <td>Final round of reporting in person at the allotted institute</td>
						<td>On or before Monday 1st August,2016</td>
					</tr>
				</table>
		<p>Note:* - If Time is unspecified, then know and follow the business hours of the concerned participating institute.</p>
	       
         </div>
       </div>
      </div>
 </div>

 <div class="col-sm-4 ">
   <div class="well">      
       <ul>
	        <li><h1>Attension !<?php echo " - ".$_SESSION['username'];   ?></h1></li>
           <li><p>Read Important Information Before Filling The Information</p></li>
           <li><p>Before Filling application you must insure that you have a Recently taken photograph</p></li>
           <li><p>Photo graph Should be in proper format as Specified in Broucher </p></li>
           <li><p>Date Of photograph taken must be specified </p></li>
           <li><p>No Correction Will Be Allowed After Filling Application</p></li>
           <li><p>Photo graph Should be Clear </p></li>
           <li><p>Read the Declaration Of eligibility carefully and give consent on it before submitting the Form  </p></li>
           <li><a><p>Read More....!</p></a></li>
		</ul>
   </div>
 </div>
<div class="col-sm-12 " style="font-size:18px;text-align:left;color:#330099;font-family:myFirstFont_three; text-align:left">
    <div class="well">
      <div class="left-side">
        <p>NIT MCA is one of the heighly recognized course in INDIA and also outside
        of india. Course Structure is designed such as per industry requirments.</p>
        <p>MCA Students are most required in outside of india i.e Austrailia Japan USA as well as UK</p>
		<p>National Institute of technology (NITs) are institute
		of national importance and are centrally founded Technical institute . 
		Thw NIMCET is a NIT MCA Common Entrance Test .a national level test conducted ny NITs for admissionin to their MCA program
		. The Admission to the MCA Program into NITs  at AGARTALA ALLAHABAD CHOPAL CALICUT DURGAPUR JAMSHEDPUR KURUKSHETRA TRICHY
		and WARANGAL for the year is based on the Rank obtained--</p>
	    <p>in NIMCET 2016 ONLY . The curiculum and syllabi of master of 
		ComputerApplication (MCA) Program ini NITs are designed consideration 
        the need of different information
         Tecnology firm Mca graduates have heighlypotential for jobs in IT sector
         </p>	  
	  </div>
    </div>
</div>
<div class="col-sm-12 ">
      <?php include '../footer-header/footer.php'; ?>
</div>
<script type="text/javascript" ></script>
</body>
</html>