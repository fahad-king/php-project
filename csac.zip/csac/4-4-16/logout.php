<?php
    session_start();
	if(isset($_SESSION['username']))
	{	
      session_destroy();
      header('Location:../home.php');
      exit();
	}
    else{
	echo "<b><i>FORBIDDEN!</i></b>". " --------------->" . " DOnt Try TO HACK !.<br/> ". "You Are Not Logged In Please Logout ";	
		
	}		
?>