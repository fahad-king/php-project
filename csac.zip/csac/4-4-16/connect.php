<?php
$con =new mysqli('localhost','root','amit','testdb') or die("Cant Connect To Server");
?>